//package utilities;
//
//import java.io.FileReader;
//import java.io.IOException;
//import java.util.Properties;
//
//public class ReadPropertyFile {
//
//	public static void main(String[] args) throws IOException {
//		
//		//configuring config.properties file to use it our project
//		FileReader fr2= new FileReader("C:\\Users\\KIIT\\eclipse-workspace-Practice\\SeleniumFramework2024\\TestAutomationFramework\\src\\test\\resources\\configfiles\\config.properties"); 
//	
//		Properties p = new Properties();
//		p.load(fr2);
//		
//		
//		System.out.println(p.getProperty("browser"));
//		System.out.println(p.getProperty("testurl"));
//		
//		
//	}
//
//}
